Implementation  of the CN2 rule based classifier. Currently works only with discrete data.
